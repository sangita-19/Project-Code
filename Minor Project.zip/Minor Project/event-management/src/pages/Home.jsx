import React from 'react'
import { Form, Button, Container,Row,Col} from 'react-bootstrap';

const Home = () => {
  return (
    <main className='d-flex flex-column min-vh-100' style={{backgroundImage:"url('./src/assets/corporate.jpg')",backgroundSize:'cover'}}>
    <div className='text-center p-3 m-3'>
      <h1 style={{color:'#e91e63'}}>Rossy Decor Event Management Company</h1>
      <h3 style={{color:'#47e91eff'}}>"Make Your Event Memorable"</h3>
      </div>
      <p className='text-light text-center fw-bold'>Welcome to Rossy Decor Event Management Company  – where every event becomes a memorable experience. We turn your ideas into reality with creativity, precision, and passion.

At Rossy Decor Event Management Company, we don’t just plan events — we craft moments. From weddings to corporate functions, we manage it all with excellence.
Your celebration is our commitment. Rossy Decor offers end-to-end event solutions that are professional, stylish, and stress-free.
Making your special occasions unforgettable — Rossy Decor Event Management Company brings together imagination, planning, and flawless execution.
</p>

     <Container className="text-light mt-5 border rounded p-3 ms-auto" style={{ maxWidth: '600px'}}>
      
      <h3 className="mb-4 text-center">Event Booking </h3>
      <Form>
        <Form.Group controlId="formName" className="mb-3">
          <Form.Label className='fw-bold'>Name</Form.Label>
          <Form.Control type="text" placeholder="Enter your full name" />
        </Form.Group>

        <Form.Group controlId="formEmail" className="mb-3">
          <Form.Label className='fw-bold'>Email address</Form.Label>
          <Form.Control type="email" placeholder="Enter your email" />
        </Form.Group>

        <Form.Group controlId="formPhone" className="mb-3">
          <Form.Label className='fw-bold'>Phone Number</Form.Label>
          <Form.Control type="tel" placeholder="Enter your phone number" />
        </Form.Group>

        <Form.Group controlId="formEvent" className="mb-3">
          <Form.Label className='fw-bold'>Select Event</Form.Label>
          <Form.Select>
            <option>All Categories</option>
            <option>Wedding</option>
            <option>Corporate</option>
            <option>Birthday</option>
            <option>Concert</option>
          </Form.Select>
</Form.Group>

        <Form.Group controlId="formDate" className="mb-3">
          <Form.Label className='fw-bold'>Event Date</Form.Label>
          <Form.Control type="date" />
        </Form.Group>

        <Form.Group controlId="formMessage" className="mb-3">
          <Form.Label className='fw-bold'>Additional Notes</Form.Label>
          <Form.Control as="textarea" rows={3} placeholder="Any special requirements?" />
        </Form.Group>

        <div className="text-center">
          <Button className='border rounded-pill' variant="primary" type="submit">
            Book Now
          </Button>
        </div>
      </Form>
    </Container>
      </main>
  )
}

export default Home