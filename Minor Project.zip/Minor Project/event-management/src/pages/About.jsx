import React from 'react'

const About = () => {
  return (
    <>
    <div className='fs-5 p-3'>
      <h2 className='text-center p-3' style={{color:'purple'}}>About Us</h2>
      <div className='text-center bg-light'>
      <div className='bg-light border rounded p-1 m-2 d-inline-block text-light'>
      <img src='./src/assets/marriage.jpg' className='border rounded' height='200' width='250'/>
    </div>
    <div className='bg-light border rounded p-1 m-2 d-inline-block text-light'>
      <img src='./src/assets/corporate.jpg' className='border rounded' height='200' width='250'/>
      
    </div>
    <div className='border rounded p-1 m-2 d-inline-block'>
      <img src='./src/assets/music.jpg' className='border rounded' height='200' width='250'/>
      
    </div>
    </div>
    <p className='fs-6 fw-bold p-3 text-center'>  Welcome to Rossy Decor, your trusted partner in turning ideas into unforgettable experiences. We are a full-service event management company specializing in organizing and executing a wide range of events—from corporate conferences and brand launches to weddings, birthdays, and cultural programs.

With a passionate and experienced team, we bring creativity, precision, and professionalism to every event we handle. Our mission is to deliver seamless experiences that reflect your vision while exceeding your expectations.

At Rossy Decor, we believe every event tells a story. Let us help you tell yours—with elegance, style, and impact.
</p>

<h4>Why Choose Us</h4>
<ul className='fs-6'>
 <li> Creative event concepts </li> 
 <li> Timely and budget-friendly execution </li> 
 <li> Skilled and professional team  </li>
 <li> End-to-end event solutions</li>
</ul>
    </div>
    
  </>
  )
}

export default About