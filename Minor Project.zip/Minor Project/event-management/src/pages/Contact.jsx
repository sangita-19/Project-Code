import React from 'react';
import { Form, Button, Container } from 'react-bootstrap';

function Contact() {
  return (
    <main className='text-light' style={{backgroundImage:"url('./src/assets/music.jpg')",backgroundSize:'cover'}}>
      <h2 className='text-center p-3' style={{color:'orange'}}>Get in Touch with Rossy Decor Event Management Company</h2>

<p className='text-center p-2'>We’d love to hear from you! Whether you're planning a wedding, corporate event, or a private celebration — our team is ready to help.
  Let’s make your event unforgettable. Reach out to us and our team will be in touch shortly.
</p> 
<div className='d-flex justify-content-center m-3 p-3'>
  <div className='d-inline-block m-3 me-5'>
<h5>Contact Information</h5>
📍<b> Office Address:</b> <br/> 
<p>Rossy Decor Event Management Company<br/>  
123 Celebration Street, Berhampore, West Bengal - 742101<br/><br/>

📞 <b>Phone:</b> +91 98765 43210  <br/>
📧 <b>Email: </b>rossydecor@gmail.com
</p>
<h5>Business Hours  </h5>
<p><b>Monday – Saturday:</b> 10:00 AM – 7:00 PM  <br/>
<b>Sunday:</b> Closed (Available on request for events)

</p>
</div>
<div className='d-inline-block m-3'>
<Container className="border rounded fw-bold p-5" style={{ maxWidth: '600px' }}>
      <h3 className="mb-4 text-center">Contact Us</h3>
      <Form>
        <Form.Group controlId="formName" className="mb-3">
          <Form.Label>Name</Form.Label>
          <Form.Control type="text" placeholder="Enter your name" />
        </Form.Group>

        <Form.Group controlId="formEmail" className="mb-3">
          <Form.Label>Email</Form.Label>
          <Form.Control type="email" placeholder="Enter your email" />
        </Form.Group>

        <Form.Group controlId="formMessage" className="mb-3">
          <Form.Label>Message</Form.Label>
          <Form.Control as="textarea" rows={4} placeholder="Type your message" />
        </Form.Group>

        <div className="text-center p-3">
          <Button className='border rounded-pill' variant="primary" type="submit">
            Send Message
          </Button>
        </div>
      </Form>
</Container>
</div>

</div>

</main>
  );
  
}

export default Contact;