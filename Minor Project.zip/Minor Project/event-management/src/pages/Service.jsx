import React from 'react'

const Service = () => {
  return (
    
     <section class="services" id="services">
      <div className='justify-content-center'>
      <h2 className='text-center p-3 m-3' style={{color:'purple'}}>Our Services</h2>
      <p className='text-center fw-bold fs-5'>At Rossy Decor, we offer end-to-end event management services tailored to your unique needs. Whether it’s a grand celebration or a professional gathering, we ensure every detail is flawlessly executed.</p>
      <div className='text-center p-5 m-3'>
        <div className="border rounded text-center d-inline-block p-3 m-3" style={{background:'#f0f0f0',height:'200px',width:'230px'}}>
          <h5 style={{color:'#e91e63'}}>Wedding Planning</h5>
          <p>Full-service planning from venues to vendors, ensuring your big day is stress-free and magical.</p>
        </div>

        <div className="border rounded text-center d-inline-block p-3 m-3" style={{background:'#f0f0f0',height:'200px',width:'230px'}}>
          <h5 style={{color:'#e91e63'}}>Corporate Events</h5>
          <p>Professional planning for conferences, seminars, and product launches tailored to your brand.</p>
        </div>

        <div className="border rounded text-center d-inline-block p-3 m-3" style={{background:'#f0f0f0',height:'200px',width:'230px'}}>
          <h5 style={{color:'#e91e63'}}>Birthday Parties</h5>
          <p>Creative and fun birthday party setups for all ages with customized themes and entertainment.</p>
        </div>

        <div className="border rounded text-center d-inline-block p-3 m-3" style={{background:'#f0f0f0',height:'200px',width:'230px'}}>
          <h5 style={{color:'#e91e63'}}>Concert & Festivals </h5>
          <p>Comprehensive services including stage setup, crowd control, and artist coordination.</p>
        </div>
        </div>
       </div> 
    
  </section>

  )
}

export default Service