import React from 'react'


const Venue = () => {
  return (
    <>
      <h2 className='p-3 text-center' style={{ color: 'purple' }}>Best Events & Wedding Venues</h2>
      <p className='fw-bold text-center p-2'>Find the perfect setting for your special day. From elegant banquet halls to open-air destinations, we bring you the best venues to match your event vision.
        Every great event starts with the right location. Explore our curated list of stunning venues suited for weddings, corporate events, and celebrations of all kinds.
        Your dream venue is just a click away. 
      </p>
      <div className='text-center'>
        <div className='bg-light border rounded p-3 m-3 d-inline-block'>
          <img src='./src/assets/p1.jpg' height='200px' width='250px' />
          <h6>Place: AC Pradhan Banquet Hall</h6>
          <b>Location:</b> South Kolkata, West Bengal<br /><br />
          <button className='bg- text-light border rounded-pill' style={{ background: '#e91e63' }}>Select</button>
        </div>
        <div className='bg-light border rounded rounded p-3 m-3 d-inline-block'>
          <img src='./src/assets/p2.avif' height='200px' width='250px' />
          <h6>Place: Aryan Palace</h6>
          <b>Location: </b>Mukundapur, Kolkata<br /><br />
          <button className='text-light border rounded-pill' style={{ background: '#e91e63' }}>Select</button>
        </div>
        <div className='bg-light border rounded rounded p-3 m-3 d-inline-block'>
          <img src='./src/assets/p3.jpg' height='200px' width='250px' />
          <h6>Place: Chowdhury House</h6>
          <b>Location:</b> Kolkata, West Bengal<br /><br />
          <button className='text-light border rounded-pill' style={{ background: '#e91e63' }}>Select</button>
        </div>
      </div>
      <div className='text-center'>
        <div className='bg-light border rounded rounded p-3 m-3 d-inline-block'>
          <img src='./src/assets/p4.jpg' height='200px' width='250px' />
          <h6>Place: Rajbari Bawali</h6>
          <b>Location:</b> South 24 Parganas, West Bengal<br /><br />
          <button className='text-light border rounded-pill' style={{ background: '#e91e63' }}>Select</button>
        </div>
        <div className='bg-light border rounded rounded p-3 m-3 d-inline-block'>
          <img src='./src/assets/p5.jpeg' height='200px' width='250px' />
          <h6>Place: Siliguri Club</h6>
          <b>Location:</b> Siliguri, West Bengal<br /><br />
          <button className='text-light border rounded-pill' style={{ background: '#e91e63' }}>Select</button>
        </div>
        <div className='bg-light border rounded rounded p-3 m-3 d-inline-block'>
          <img src='./src/assets/p6.avif' height='200px' width='250px' />
          <h6>Place: Shri Vrandavan Marriage Garden</h6>
          <b>Location:</b> Gadarwara, Madhya Pradesh<br /><br />
          <button className='text-light border rounded-pill' style={{ background: '#e91e63' }}>Select</button>
        </div>
      </div>
    </>
  )
}

export default Venue