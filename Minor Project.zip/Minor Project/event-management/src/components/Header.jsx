import React from 'react'
import { Link } from 'react-router-dom';
import { Navbar, Nav, Container } from 'react-bootstrap';

const Header = () => {

  return <>
    <Navbar className="bg-dark p-3" expand="lg">
      <Container fluid>
      <Navbar.Brand className='text-primary'><img src="./src/assets/preview.png" height="70px" width="70px" className='border border-warning rounded-pill'/><h4 className='d-inline-block p-3'>Rossy Decor</h4></Navbar.Brand>
      <Nav>
        <Link className='nav-link text-light fw-bold' to="/">Home </Link>
        <Link className='nav-link text-light fw-bold' to="/about">About Us</Link>
        <Link className='nav-link text-light fw-bold' to="/service">Our Services</Link>
        <Link className='nav-link text-light fw-bold' to="/venue">Venues</Link>
        <Link className='nav-link text-light fw-bold' to="/contact">Contact Us</Link>
      </Nav>
      
      </Container>
    </Navbar>

  </>
}

export default Header;