import React from 'react'

export const Footer = () => {
  return (
    <>
     
    <div className='bg-dark text-light text-center fixed-bottom'>© 2025 Rossy Decor | All Rights Reserved<br></br>
    Email Id: rossydecor@gmail.com ; Mobile: +91 8768450512 

    </div>
    </>
  )
}
export default Footer